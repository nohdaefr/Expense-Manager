import React, { useState } from 'react';


function TotalExpenses({ expenses }) {
    const total = expenses.reduce((acc, expense) => acc + expense.amount, 0);
    return (
      <div>
        <h2>Total Expenses: ${total.toFixed(2)}</h2>
      </div>
    );
  }
  export default TotalExpenses;