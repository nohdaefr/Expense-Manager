import React, { useState } from 'react';
import './header1.css'; // Adjust the path if necessary
import ExpenseForm from './ExpenseFolder/ExpenseForm';
import ExpenseList from './ExpenseFolder/ExpenseList';
import TotalExpenses from './ExpenseFolder/TotalExpense';
import './App.css';  

function App() {
  const [expenses,setExpenses] = useState([]);

  // Function to add a new expense
  const addExpense = (expense) => {
    setExpenses([...expenses, expense]);
  };

  return (
    <div className='Header1'>
      <h1>Expense Manager</h1>

      {/* Form to add new expenses */}
      <ExpenseForm onAddExpense={addExpense} />

      {/* Display list of expenses */}
      <ExpenseList expenses={expenses} />

      {/* Display total expenses */}
      <TotalExpenses expenses={expenses} />
    </div>
  );
}

export default App;



